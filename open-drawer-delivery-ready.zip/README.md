# Pendrive Online

Starter fullstack project (React frontend + Node/Express backend) for an online "pendrive":
- User auth (email/password with JWT)
- Upload/download/rename/delete files
- S3 support with presigned uploads (recommended)
- Local storage fallback using lowdb for metadata

## Quick start (local)
1. Backend:
   - cd backend
   - npm install
   - set environment variables (create .env if needed)
   - node server.js

2. Frontend:
   - cd frontend
   - npm install
   - npm run dev

## Deploy
- Frontend: Vercel recommended
- Backend: Heroku / Railway / Render
- Use S3 in production (set USE_S3=true and AWS credentials)

## Features implemented in this ZIP
- Presigned URL endpoint on backend (`/api/presign`) and frontend flow
- Migration scripts for Postgres and Mongo
- GitHub Actions workflow and Dockerfile/Procfile for easy deploy
- Branding SVG logo

