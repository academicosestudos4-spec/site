
/* backend/server.js - improved by assistant */
require('dotenv').config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Low, JSONFile } = require('lowdb');
const { nanoid } = require('nanoid');
const AWS = require('aws-sdk');
const mime = require('mime-types');
const rateLimit = require('express-rate-limit');

// --- Env validation ---
const requiredEnvs = ['PORT','JWT_SECRET'];
requiredEnvs.forEach(k => {
  if (!process.env[k]) {
    console.error(`Missing required env var: ${k}. Please set it (see .env.example).`);
    // do not exit in hosted environments; but exit in local dev to surface the issue
    if (process.env.NODE_ENV !== 'production') process.exit(1);
  }
});

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
const STORAGE_TYPE = (process.env.STORAGE_TYPE || 's3'); // local | s3

// Ensure upload dir exists
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// --- S3 setup (optional) ---
let s3 = null;
if (STORAGE_TYPE === 's3') {
  if (!process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY || !process.env.S3_BUCKET || !process.env.AWS_REGION) {
    console.error('S3 selected but AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION or S3_BUCKET missing in env.');
    if (process.env.NODE_ENV !== 'production') process.exit(1);
  }
  AWS.config.update({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION
  });
  s3 = new AWS.S3();
}

// --- DB (lowdb) for metadata ---
const dbFile = path.join(__dirname, 'db.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);

(async () => {
  await db.read();
  db.data = db.data || { users: [], files: [] };
  await db.write();
})();

const app = express();
// Trust proxy when behind a reverse proxy (nginx, cloud load balancers)
app.set('trust proxy', true);

// CORS: allow all origins for global access — in production restrict to known domains.
const corsOptions = {
  origin: function(origin, callback){ callback(null, true); },
  exposedHeaders: ['Authorization']
};
app.use(require('cors')(corsOptions));
app.use(express.json());

// Middleware to capture Accept-Language for simple locale awareness
app.use((req, res, next) => {
  req.locale = req.headers['accept-language'] ? req.headers['accept-language'].split(',')[0] : 'en';
  res.setHeader('Vary', 'Accept-Language');
  next();
});


// --- Rate limiter ---
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 60 // limit each IP to 60 requests per windowMs
});
app.use(limiter);

// --- Multer config ---
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const id = nanoid();
    const ext = path.extname(file.originalname);
    cb(null, id + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: function (req, file, cb) {
    // basic mime-type check
    if (!file.mimetype) return cb(null, false);
    cb(null, true);
  }
});

// --- Helpers ---
function sanitizeFilename(name) {
  return name.replace(/[^a-zA-Z0-9._-]/g, '_');
}

const { execFile } = require('child_process');
function scanFileWithClam(filePath){
  return new Promise((resolve, reject)=>{
    // Use clamscan CLI (installed in container via apk). Return {clean:true} or {infected:true, reason}
    execFile('clamscan', ['--no-summary', filePath], {timeout: 120000}, (err, stdout, stderr) => {
      if (err){
        // clamscan returns non-zero when infected; we need to inspect stdout
        const out = stdout || '';
        if (out.toLowerCase().includes('infected')){
          return resolve({infected:true, details: out});
        }
        return reject(new Error('clamscan error: '+(stderr||err.message)));
      }
      return resolve({clean:true});
    });
  });
}

// --- Simple auth (demo) ---
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'username and password required' });
  await db.read();
  const exists = db.data.users.find(u => u.username === username);
  if (exists) return res.status(400).json({ error: 'user exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = { id: nanoid(), username, password: hash };
  db.data.users.push(user);
  await db.write();
  res.json({ ok: true });
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  await db.read();
  const user = db.data.users.find(u => u.username === username);
  if (!user) return res.status(401).json({ error: 'invalid' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ error: 'invalid' });
  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

function authMiddleware(req, res, next) {
  const h = req.headers.authorization;
  if (!h) return res.status(401).json({ error: 'no auth' });
  const parts = h.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'bad auth' });
  const token = parts[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'invalid token' });
  }
}

// --- Endpoints ---
app.get('/api/status', (req, res) => {
  res.json({ ok: true, env: STORAGE_TYPE, time: new Date().toISOString() });
});

// Upload file (authenticated)
app.post('/api/upload', authMiddleware, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'no file' });
  const originalName = sanitizeFilename(req.file.originalname);
  const id = path.basename(req.file.filename, path.extname(req.file.filename));
  let storageInfo = { type: 'local', path: req.file.path };
  // If S3 selected, upload the file to S3 and remove local copy
  if (STORAGE_TYPE === 's3' && s3) {
    const fileStream = fs.createReadStream(req.file.path);
    const s3Key = `${id}${path.extname(req.file.filename)}`;
    await s3.upload({ Bucket: process.env.S3_BUCKET, Key: s3Key, Body: fileStream, ContentType: req.file.mimetype }).promise();
    // remove local copy
    try { fs.unlinkSync(req.file.path); } catch(e){}
    storageInfo = { type: 's3', key: s3Key, bucket: process.env.S3_BUCKET };
  }
  // Run antivirus scan if enabled
  try{
    const scanRes = await scanFileWithClam(req.file.path);
    if (scanRes.infected){
      // remove file and refuse
      try{ fs.unlinkSync(req.file.path); }catch(e){}
      return res.status(400).json({ error: 'file infected', details: scanRes.details });
    }
  }catch(e){
    console.warn('Antivirus scan failed or not available:', e.message);
    // proceed cautiously - here we allow upload but log warning
  }

  // Save metadata
  await db.read();
  const meta = {
    id,
    filename: originalName,
    size: req.file.size,
    mime: req.file.mimetype,
    owner: req.user.id,
    storage: storageInfo,
    createdAt: new Date().toISOString()
  };
  db.data.files.push(meta);
  await db.write();
  res.json({ ok: true, file: meta });
});

// List files for user
app.get('/api/files', authMiddleware, async (req, res) => {
  await db.read();
  const files = db.data.files.filter(f => f.owner === req.user.id);
  res.json({ files });
});

// Download by id (authenticated)
app.get('/api/download/:id', authMiddleware, async (req, res) => {
  const id = req.params.id;
  await db.read();
  const f = db.data.files.find(x => x.id === id);
  if (!f) return res.status(404).json({ error: 'not found' });
  if (f.owner !== req.user.id) return res.status(403).json({ error: 'forbidden' });
  if (f.storage.type === 'local') {
    const filePath = f.storage.path;
    return res.download(filePath, f.filename);
  } else if (f.storage.type === 's3') {
    const params = { Bucket: f.storage.bucket, Key: f.storage.key, Expires: 60 };
    const url = s3.getSignedUrl('getObject', params);
    return res.json({ url });
  } else {
    return res.status(500).json({ error: 'unknown storage' });
  }
});


// --- Admin middleware ---
function adminAuth(req, res, next){
  // Allow admin via env token or username 'admin'
  const adminToken = process.env.ADMIN_TOKEN || null;
  const h = req.headers.authorization;
  if (adminToken && h && h.split(' ')[1]===adminToken) return next();
  if (req.user && req.user.username === 'admin') return next();
  return res.status(403).json({error:'admin only'});
}

// Admin endpoints
app.get('/api/admin/users', authMiddleware, adminAuth, async (req,res)=>{ await db.read(); res.json({users: db.data.users}); });
app.delete('/api/admin/users/:id', authMiddleware, adminAuth, async (req,res)=>{ await db.read(); db.data.users = db.data.users.filter(u=>u.id !== req.params.id); await db.write(); res.json({ok:true}); });
app.get('/api/admin/files', authMiddleware, adminAuth, async (req,res)=>{ await db.read(); res.json({files: db.data.files}); });
app.delete('/api/admin/files/:id', authMiddleware, adminAuth, async (req,res)=>{ await db.read(); const f = db.data.files.find(x=>x.id===req.params.id); if(!f) return res.status(404).json({error:'not found'}); // delete storage
 if(f.storage.type==='local'){ try{ fs.unlinkSync(f.storage.path); }catch(e){} } else if(f.storage.type==='s3'){ try{ s3.deleteObject({Bucket:f.storage.bucket, Key:f.storage.key}).promise(); }catch(e){} }
 db.data.files = db.data.files.filter(x=>x.id!==req.params.id); await db.write(); res.json({ok:true}); });

// Static serving for frontend (optional)
app.use('/', express.static(path.join(__dirname, '..', 'frontend')));

// Start
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT} (storage=${STORAGE_TYPE})`);
});
