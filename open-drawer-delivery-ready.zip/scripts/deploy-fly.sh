#!/usr/bin/env bash
# deploy-fly.sh - deploy Open Drawer to Fly.io
# Requirements: flyctl installed and logged in, Docker installed
set -euo pipefail
APP_NAME=${1:-open-drawer}
echo "Building backend Docker image..."
docker build -t ${APP_NAME}-backend:latest ./backend
echo "Creating fly app if not exists..."
if ! flyctl apps list | grep -q "${APP_NAME}"; then
  flyctl apps create ${APP_NAME} || true
fi
echo "Setting up secrets (you will be prompted or set env vars):"
read -p "Enter AWS_ACCESS_KEY_ID: " AWS_ACCESS_KEY_ID
flyctl secrets set AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID
read -p "Enter AWS_SECRET_ACCESS_KEY: " AWS_SECRET_ACCESS_KEY
flyctl secrets set AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY
read -p "Enter S3_BUCKET: " S3_BUCKET
flyctl secrets set S3_BUCKET=$S3_BUCKET
read -p "Enter S3_REGION: " S3_REGION
flyctl secrets set S3_REGION=$S3_REGION
read -p "Enter JWT_SECRET (or leave blank to generate): " JWT_SECRET
if [ -z "$JWT_SECRET" ]; then JWT_SECRET=$(openssl rand -hex 32); echo "Generated JWT_SECRET: $JWT_SECRET"; fi
flyctl secrets set JWT_SECRET=$JWT_SECRET
read -p "Enter ADMIN_TOKEN (for admin dashboard): " ADMIN_TOKEN
flyctl secrets set ADMIN_TOKEN=$ADMIN_TOKEN
echo "Deploying to Fly..."
flyctl deploy --image ${APP_NAME}-backend:latest --app ${APP_NAME}
echo "Deployment complete. Visit: https://${APP_NAME}.fly.dev"
