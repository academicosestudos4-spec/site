#!/usr/bin/env bash
# deploy.sh - deploy project to a remote host via SSH and run docker-compose
# Usage: ./deploy.sh user@host /path/on/remote
set -euo pipefail
REMOTE=${1:-}
REMOTE_PATH=${2:-/opt/pendrive-online}
if [ -z "$REMOTE" ]; then
  echo "Usage: $0 user@host [remote_path]"
  exit 1
fi
echo "Packing project..."
tar -czf /tmp/pendrive-deploy.tar.gz -C "$(pwd)" .
echo "Copying to remote..."
scp /tmp/pendrive-deploy.tar.gz ${REMOTE}:/tmp/
echo "Extracting on remote..."
ssh ${REMOTE} "mkdir -p ${REMOTE_PATH} && tar -xzf /tmp/pendrive-deploy.tar.gz -C ${REMOTE_PATH} && cd ${REMOTE_PATH} && docker-compose -f docker-compose.prod.yml pull || true && docker-compose -f docker-compose.prod.yml up -d --build"
echo "Deployed to ${REMOTE}:${REMOTE_PATH}"
