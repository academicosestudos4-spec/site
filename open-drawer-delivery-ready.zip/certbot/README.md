Certbot with nginx (manual steps):

1. Install certbot on the host or use certbot docker image.
2. Stop nginx container temporarily (if it binds port 80) or use --nginx plugin.
3. Run certbot to obtain certificates for your domain:
   certbot certonly --standalone -d yourdomain.com -d www.yourdomain.com
4. Place the generated certs inside nginx container or mount host folders:
   /etc/letsencrypt/live/yourdomain.com/fullchain.pem
   /etc/letsencrypt/live/yourdomain.com/privkey.pem
5. Update nginx config to use ssl_certificate and ssl_certificate_key and reload nginx.
