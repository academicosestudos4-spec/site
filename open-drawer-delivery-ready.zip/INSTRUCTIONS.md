# Open Drawer — Full deployment & setup instructions

This document walks you through every step to deploy **Open Drawer** to Fly.io with S3 storage, configure DNS and TLS, and manage the app. It also includes Traefik/Caddy examples and a security checklist.

## Prerequisites
- A computer with Docker installed.
- `flyctl` installed and an account at https://fly.io.
- An AWS account with access to S3 (or a compatible S3 provider like Backblaze/Wasabi/Cloudflare R2).
- A domain name if you want a custom domain (optional).

## Quick deploy (recommended)
1. Download and extract the project zip you received.
2. Open a terminal in the project root.
3. Ensure you're logged into Fly:
   ```bash
   flyctl auth login
   ```
4. Run the deploy script:
   ```bash
   ./scripts/deploy-fly.sh open-drawer
   ```
   The script will:
   - Build the backend Docker image.
   - Create the Fly app (if needed).
   - Prompt for AWS credentials (it stores them as Fly secrets).
   - Deploy the app.
5. After deployment, visit:
   `https://open-drawer.fly.dev` (or the app name you chose).

## Setting up S3 (AWS) — minimal steps
1. Create an S3 bucket (e.g., `open-drawer-uploads`) in your AWS Console.
2. Create an IAM user with `Programmatic access` and attach a policy with S3 Put/Get/Delete permissions for that bucket.
3. Save the `Access key ID` and `Secret access key` — you'll input these when running `deploy-fly.sh`.

## Custom domain (DNS) with Fly.io
1. In Fly dashboard, open your app > Network > Certificates. Add your domain.
2. Fly will show DNS records to add (CNAME to Fly's endpoints or A/AAAA records). Add them in your DNS provider.
3. Wait for propagation and Fly will provision TLS certificates automatically.

## Traefik (example) — if you prefer Traefik on your own VPS
1. Use `traefik/README.md` as a starting point.
2. Ensure Docker socket is available and configure `certificatesresolvers` properly.
3. Add labels to your backend service in docker-compose to let Traefik route to it.

## Caddy (example)
1. See `caddy/Caddyfile`. Caddy will automatically obtain TLS for your domain when reachable on port 80/443.

## Security checklist (high level)
- [ ] Replace `JWT_SECRET` with a long, random hex secret and store in secrets manager.
- [ ] Set `ADMIN_TOKEN` to a secure random string and keep it secret.
- [ ] Restrict CORS origins in `backend/server.js` to only trusted domains.
- [ ] Use S3 with private objects + signed URLs for downloads.
- [ ] Configure rate-limiting and request size limits (already configured).
- [ ] Run `npm audit` and update vulnerable packages.
- [ ] Set up monitoring and alerts for uploads, disk usage, and suspicious activity.
- [ ] Schedule `freshclam` updates for ClamAV (cron or container restart policy).

## Admin dashboard
- URL: `/admin.html`
- Use the `ADMIN_TOKEN` as the Bearer token for access (the dashboard uses it directly).

## Support
If you want, I can generate step-by-step screenshots for the Fly.io flow (I will include placeholders), or provide a video walkthrough script you can record.
