# DNS & Reverse Proxy (Traefik / Caddy) — Step-by-step

## Traefik (self-hosted on VPS)
1. Install Docker and docker-compose on your VPS.
2. Configure `traefik` service with ACME (Let's Encrypt), set your email in the config.
3. Start Traefik and confirm dashboard at :8080 (if enabled).
4. In your backend's docker-compose, add labels to service:
   ```yaml
   labels:
     - "traefik.enable=true"
     - "traefik.http.routers.opendrawer.rule=Host(`open.yourdomain.com`)"
     - "traefik.http.routers.opendrawer.entrypoints=websecure"
     - "traefik.http.routers.opendrawer.tls=true"
     - "traefik.http.routers.opendrawer.tls.certresolver=myresolver"
     - "traefik.http.services.opendrawer.loadbalancer.server.port=4000"
   ```
5. Add DNS A records for `open.yourdomain.com` pointing to your VPS IP.

## Caddy (easiest self-hosted)
1. Install Caddy on the VPS or run via Docker.
2. Use the provided `caddy/Caddyfile` and replace `yourdomain.com` with your domain.
3. Ensure DNS A record points to your VPS IP.
4. Start Caddy. It will auto-issue TLS certs.

