# Security Audit — Open Drawer (automated overview)

This is a concise security review of the current codebase and deployment configuration with recommended fixes.

## Findings
- **Secrets in env**: JWT_SECRET and ADMIN_TOKEN must be strong and kept out of source control. Use Fly secrets or a secrets manager.
- **CORS wide open**: backend currently allows all origins. Restrict to your domain(s) in production.
- **lowdb for metadata**: lowdb stores data in a local JSON file (db.json). Not suitable for multi-instance deployments — use Postgres or Mongo for production.
- **Antivirus**: ClamAV is integrated, but ensure `freshclam` runs regularly to update signatures.
- **Rate limiting**: present (60 req/min). Consider adjusting per endpoint and adding IP bans for abnormal behavior.
- **Input validation**: filename sanitization present, but additional checks on MIME types and file content are recommended.
- **Dependency updates**: run `npm audit` and `npm outdated`. Update vulnerable packages before production.

## Recommendations (priority order)
1. Rotate and store secrets securely (high). Use Fly secrets or AWS Secrets Manager.
2. Replace lowdb with a managed DB (Postgres) and enable backups (high).
3. Harden CORS and implement CSP (Content Security Policy) headers (high).
4. Configure ClamAV DB updates and use `clamd` for better performance (medium).
5. Enable logging/monitoring (e.g., Sentry, Datadog) and set alerts (medium).
6. Add unit & integration tests, CI pipeline, and pre-deploy security scans (medium).

