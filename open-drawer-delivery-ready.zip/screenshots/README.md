Place screenshot images here for documentation. Example filenames: 01_fly_login.png, 02_deploy.png
