-- Postgres schema for pendrive-online
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE files (
  id TEXT PRIMARY KEY,
  owner_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  original_name TEXT,
  stored_name TEXT,
  mime TEXT,
  size BIGINT,
  storage TEXT,
  s3_bucket TEXT,
  s3_key TEXT,
  local_path TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE INDEX idx_files_owner ON files(owner_id);
