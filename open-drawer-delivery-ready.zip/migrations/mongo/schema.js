// Example Mongoose schemas for users and files
const mongoose = require('mongoose');
const { Schema } = mongoose;

const UserSchema = new Schema({
  _id: String,
  email: { type: String, unique: true },
  password: String,
  name: String,
  createdAt: { type: Date, default: Date.now }
});

const FileSchema = new Schema({
  _id: String,
  ownerId: { type: String, ref: 'User' },
  originalName: String,
  storedName: String,
  mime: String,
  size: Number,
  storage: String,
  s3: {
    bucket: String,
    key: String
  },
  localPath: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = { UserSchema, FileSchema };
