# Video walkthrough script - Open Drawer deploy
1. Intro (10s): Explain Open Drawer purpose.
2. Show project files and open scripts/deploy-fly.sh (20s).
3. Demonstrate flyctl auth login (15s).
4. Run ./scripts/deploy-fly.sh and enter S3 credentials (40s).
5. Show Fly dashboard and that app is live (20s).
6. Log into app, register, upload a file, show admin dashboard (40s).
7. Conclusion and next steps (15s).
