# Pendrive Online — extracted project

This archive contains the extracted "Pendrive Online" project you uploaded.

## What I did
- Extracted the zip and inspected files.
- Located a Node/Express backend in `backend/` (server.js) and a frontend in `frontend/` (index.html).
- Found a Dockerfile for the backend and basic package.json.

## How to run locally (quick)
### Option A — Run backend with Node.js
1. Install Node 18+.
2. In `backend/`:
   ```bash
   cp .env.example .env
   npm install
   npm start
   ```
3. By default the backend exposes port 4000 (see Dockerfile). Serve `frontend/` with any static server (e.g. `python -m http.server 8000`).

### Option B — Docker (if you have Docker)
From project root:
```bash
docker build -t pendrive-backend ./backend
docker run -p 4000:4000 pendrive-backend
# serve frontend separately or add reverse proxy
```

## Improvements I suggest (I can implement them on request)
- Add `.env.example` and documentation for required env vars (JWT secret, storage config).
- Add simple reverse-proxy or nginx to serve frontend + backend together.
- Harden security: rate limiting, input validation, secure multer settings.
- Add unit tests and CI.

## Files added by assistant
- `env.example` — template env vars
- `docker-compose.yml` — quick compose to run backend + static nginx (if desired)
- `README.md` — this file



## Changes made by assistant (detailed)
- Rewrote backend/server.js to add env validation, S3/local storage selection, auth endpoints, file metadata, rate limiting, and safer multer config.
- Updated backend/package.json to include express-rate-limit and dotenv.
- Updated backend/.env.example with STORAGE_TYPE and AWS vars.
- Replaced frontend/index.html with a simple login + upload UI (demo).

## Deployment for global access / language adaptation

This project is prepared to be deployed globally behind a reverse proxy (nginx) so it can be reachable from anywhere and serve the correct language to visitors.

Options to deploy publicly:
- Use a VPS (DigitalOcean, Linode, AWS EC2) or a container service (AWS ECS, Azure Container Instances). Point your domain's DNS to the server's public IP.
- Run `docker-compose.prod.yml` on the server (ensure Docker & docker-compose are installed). Example:
  ```bash
  docker-compose -f docker-compose.prod.yml up -d --build
  ```
- Obtain TLS (HTTPS) certificates using Certbot or use a reverse-proxy like Traefik or nginx-proxy with automated Let's Encrypt. This compose file leaves port 443 commented — configure certs before enabling.

Language adaptation:
- The frontend auto-detects browser language (`navigator.language`) and tries `pt`, `es`, then `en` by default. A language selector is provided for manual override (saved in localStorage).
- The backend sets `req.locale` from the `Accept-Language` header so server-side responses can be localized if extended.

Security & production notes:
- Currently CORS is wide open to allow global access quickly. In production, set a more restrictive policy (allowed domains) in `backend/server.js` corsOptions.
- Replace `JWT_SECRET` with a strong secret (use env management). Do not check secrets into git.
- Consider using S3 (STORAGE_TYPE=s3) for scalable storage and an external database for metadata instead of lowdb for multi-instance setups.
- Monitor uploads, set virus scanning if you accept public file uploads, and enforce content-type/extension filters.



## Added deployment helpers and antivirus
- `scripts/deploy.sh` — simple SSH deploy script (requires SSH access and docker-compose on remote).
- Traefik and Caddy examples added in `/traefik` and `/caddy`.
- ClamAV integrated: backend Dockerfile installs `clamav` and `clamscan`. Uploads are scanned; infected files are rejected.
- `docker-compose.prod.yml` now includes a `clamav` service and volume for DB.

Important: The ClamAV database may need to be updated on first run (`freshclam`) and scanning relies on the `clamscan` binary available in the backend container.


## Open Drawer final (v5) - Fly.io deployment
- Use `scripts/deploy-fly.sh` to build and deploy to Fly.io. Requirements: `flyctl`, `docker`, and an account on Fly.io.
- The script will ask for AWS S3 credentials and JWT_SECRET and ADMIN_TOKEN (used for admin dashboard auth as a secret token).
- After deploy, the app will be reachable at `https://<appname>.fly.dev` (default appname: open-drawer).
- Admin dashboard: visit `/admin.html` and use the `ADMIN_TOKEN` as the Bearer token to manage users/files.
