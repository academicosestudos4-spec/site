import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function Dashboard(){
  const [files,setFiles]=useState([]);
  const [file,setFile]=useState(null);
  const [msg,setMsg]=useState('');

  useEffect(()=>{ fetchFiles() },[])

  async function fetchFiles(){
    const res = await api.get('/files');
    setFiles(res.data.files || []);
  }

  async function uploadTraditional(e){
    e.preventDefault();
    if(!file) return setMsg('Selecione um arquivo');
    const fd = new FormData(); fd.append('file', file);
    setMsg('Fazendo upload...');
    await api.post('/upload', fd);
    setFile(null); setMsg('Upload ok'); fetchFiles();
  }

  // presigned flow: ask server for URL then PUT directly
  async function uploadPresigned(e){
    e.preventDefault();
    if(!file) return setMsg('Selecione um arquivo');
    setMsg('Solicitando presigned URL...');
    const res = await api.post('/presign', { fileName: file.name, fileType: file.type });
    const { uploadURL, key } = res.data;
    setMsg('Enviando direto para S3...');
    await fetch(uploadURL, { method:'PUT', body: file, headers: { 'Content-Type': file.type } });
    setMsg('Upload concluído (presigned).');
    fetchFiles();
  }

  async function download(id){
    const res = await api.get(`/files/${id}/download`, { responseType: 'blob' });
    const cd = res.headers['content-disposition'];
    let filename = 'download';
    if(cd){ const m = /filename="?([^\"]+)"?/.exec(cd); if(m) filename = m[1] }
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); window.URL.revokeObjectURL(url);
  }

  async function remove(id){ if(!confirm('Excluir?')) return; await api.delete(`/files/${id}`); fetchFiles(); }
  async function rename(id){ const newName = prompt('Novo nome:'); if(!newName) return; await api.post(`/files/${id}/rename`, { newName }); fetchFiles(); }
  async function share(id){ const res = await api.post(`/files/${id}/share`, { expiresIn: 3600 }); alert('Link: ' + res.data.url); }

  return (
    <div className="bg-slate-50" style={{minHeight:'100vh',padding:30}}>
      <div className="container">
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <h1>Meu Pendrive</h1>
          <div>
            <button className="button" onClick={()=>{ localStorage.removeItem('token'); window.location.href='/' }}>Sair</button>
          </div>
        </div>
        <div style={{height:12}} />
        <form onSubmit={uploadTraditional} style={{display:'flex',gap:12}}>
          <input type="file" onChange={e=>setFile(e.target.files[0])} />
          <button className="button">Upload via servidor</button>
          <button className="button" onClick={uploadPresigned} type="button">Upload direto (S3)</button>
        </form>
        <div style={{marginTop:8,color:'#666'}}>{msg}</div>
        <div style={{marginTop:18}}>
          {files.length===0 && <div style={{color:'#888'}}>Nenhum arquivo</div>}
          <div style={{display:'grid',gap:10}}>
            {files.map(f=> (
              <div key={f.id} style={{display:'flex',justifyContent:'space-between',padding:10,border:'1px solid #eee',borderRadius:8}}>
                <div>
                  <div style={{fontWeight:600}}>{f.originalName}</div>
                  <div style={{fontSize:12,color:'#777'}}>{new Date(f.createdAt).toLocaleString()} • {f.size ? Math.round(f.size/1024) + ' KB' : '—'}</div>
                </div>
                <div style={{display:'flex',gap:8}}>
                  <button onClick={()=>download(f.id)} className="button" style={{background:'#fff',color:'#333',border:'1px solid #ddd'}}>Baixar</button>
                  <button onClick={()=>rename(f.id)} className="button" style={{background:'#fff',color:'#333',border:'1px solid #ddd'}}>Renomear</button>
                  <button onClick={()=>share(f.id)} className="button" style={{background:'#fff',color:'#333',border:'1px solid #ddd'}}>Compartilhar</button>
                  <button onClick={()=>remove(f.id)} className="button" style={{background:'#fff',color:'#d33',border:'1px solid #f3d'}}>{'Excluir'}</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
