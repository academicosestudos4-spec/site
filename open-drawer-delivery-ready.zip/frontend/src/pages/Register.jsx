import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';

export default function Register(){
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [name,setName]=useState('');
  const nav = useNavigate();
  const [err,setErr]=useState('');

  async function submit(e){
    e.preventDefault();
    try{
      const res = await api.post('/register',{ email, password, name });
      localStorage.setItem('token', res.data.token);
      nav('/dashboard');
    }catch(e){ setErr(e.response?.data?.error || 'Erro') }
  }

  return (
    <div className="bg-slate-50" style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <form onSubmit={submit} style={{width:360, background:'#fff', padding:20, borderRadius:10}}>
        <h2 style={{marginTop:0}}>Criar conta</h2>
        {err && <div style={{color:'red'}}>{err}</div>}
        <input className="input" placeholder="Nome" value={name} onChange={e=>setName(e.target.value)} />
        <div style={{height:8}} />
        <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <div style={{height:8}} />
        <input type="password" className="input" placeholder="Senha" value={password} onChange={e=>setPassword(e.target.value)} />
        <div style={{height:12}} />
        <button className="button" style={{width:'100%'}}>Criar</button>
      </form>
    </div>
  )
}
